public interface Protocol_Garage {
    void fixed(Vehicle vehicle);
}
